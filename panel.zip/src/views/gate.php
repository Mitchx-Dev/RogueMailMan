<?php

/**
 * This file is part of UBoat - HTTP Botnet Project
 */

echo $data;
