<?php

/**
 * This file is part of UBoat - HTTP Botnet Project
 */

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8" />
    <title>UBoat - HTTP Botnet Project</title>
    <base href="<?=goat::$app->config['base_url'];?>" />

    <link rel="stylesheet" href="css/bootstrap.min.css" type="text/css" />
    <link rel="stylesheet" href="css/style.css" type="text/css" />
    <link rel="stylesheet" href="css/font-awesome.min.css" type="text/css" />
    <link rel="stylesheet" href="js/jvectormap/jquery-jvectormap-1.2.2.css" type="text/css" />

    <script src="js/jquery-1.12.0.min.js"></script>
    <script src="js/jvectormap/jquery-jvectormap-1.2.2.min.js"></script>
    <script src="js/jvectormap/jquery-jvectormap-world-mill-en.js"></script>
    <script src="js/chartjs/Chart.js"></script>
    <script src="js/bootstrap.js"></script>
</head>
<body>
