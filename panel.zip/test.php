<?php
// generate password hash from here
echo password_hash('root', PASSWORD_DEFAULT);
